const menuToggle = document.querySelector('.menu-toggle')
const navMenu = document.querySelector('.links-container')

menuToggle.addEventListener('click', () => {
    navMenu.classList.toggle('active')
});

document.addEventListener('click', (e) => {
    if (
        !menuToggle.contains(e.target) &&
        !navMenu.contains(e.target)
    ) {
        navMenu.classList.remove('active')
    }
})